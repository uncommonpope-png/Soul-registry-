#!/bin/bash
# ============================================================
# PLT Soul Registry — Bot Registration Script
# Usage: ./register.sh <name> <role> <origin> [profit] [love] [tax]
# ============================================================
# Requires: GITHUB_PAT environment variable set
# Example:
#   export GITHUB_PAT=ghp_yourtoken
#   ./register.sh "MyBot" "Task Automation" "https://mybot.io" 75 80 25
# ============================================================

set -e

REPO="uncommonpope-png/soul-registry"
NAME="${1:-UnnamedSoul}"
ROLE="${2:-Unknown Role}"
ORIGIN="${3:-unknown}"
PROFIT="${4:-70}"
LOVE="${5:-70}"
TAX="${6:-30}"

if [ -z "$GITHUB_PAT" ]; then
  echo "❌ GITHUB_PAT not set. Export your GitHub Personal Access Token first:"
  echo "   export GITHUB_PAT=ghp_yourtoken"
  exit 1
fi

echo "🌀 Registering soul: $NAME"
echo "   Role: $ROLE"
echo "   Origin: $ORIGIN"
echo "   PLT — Profit: $PROFIT | Love: $LOVE | Tax: $TAX"

PAYLOAD=$(cat <<EOF
{
  "event_type": "bot-register",
  "client_payload": {
    "name": "$NAME",
    "role": "$ROLE",
    "capabilities": ["auto-registered"],
    "origin": "$ORIGIN",
    "plt_profit": $PROFIT,
    "plt_love": $LOVE,
    "plt_tax": $TAX
  }
}
EOF
)

RESPONSE=$(curl -s -w "\n%{http_code}" \
  -X POST \
  -H "Authorization: Bearer $GITHUB_PAT" \
  -H "Content-Type: application/json" \
  -H "Accept: application/vnd.github.v3+json" \
  -d "$PAYLOAD" \
  "https://api.github.com/repos/$REPO/dispatches")

HTTP_CODE=$(echo "$RESPONSE" | tail -n1)

if [ "$HTTP_CODE" = "204" ]; then
  echo "✅ Soul dispatched successfully. $NAME entering the Soul Economy..."
  echo "   Check: https://github.com/$REPO/actions"
  echo "   Dashboard: https://uncommonpope-png.github.io/soul-registry/"
else
  echo "❌ Registration failed. HTTP $HTTP_CODE"
  echo "$RESPONSE"
  exit 1
fi
